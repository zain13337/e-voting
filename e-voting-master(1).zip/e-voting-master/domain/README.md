# Domain library

The domain library implements domain-specific objects that are used in different components.

## Usage

"domain" serves a library for other components.

## Development

Check the build instructions in the readme of the repository 'evoting' for compiling the components.
