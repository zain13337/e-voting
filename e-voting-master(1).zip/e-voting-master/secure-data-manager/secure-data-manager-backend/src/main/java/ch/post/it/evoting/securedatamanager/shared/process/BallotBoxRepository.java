/*
 * (c) Copyright 2024 Swiss Post Ltd.
 */
package ch.post.it.evoting.securedatamanager.shared.process;

import static ch.post.it.evoting.evotinglibraries.domain.validations.Validations.validateUUID;
import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static java.util.Collections.singletonMap;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jakarta.annotation.PostConstruct;
import jakarta.json.JsonObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import com.orientechnologies.common.exception.OException;
import com.orientechnologies.orient.core.record.impl.ODocument;

import ch.post.it.evoting.evotinglibraries.domain.election.BallotBox;
import ch.post.it.evoting.evotinglibraries.domain.validations.FailedValidationException;
import ch.post.it.evoting.evotinglibraries.domain.validations.Validations;
import ch.post.it.evoting.securedatamanager.shared.JsonConstants;
import ch.post.it.evoting.securedatamanager.shared.database.DatabaseException;
import ch.post.it.evoting.securedatamanager.shared.database.DatabaseManager;

/**
 * Implementation of operations on ballot boxes.
 */
@Repository
public class BallotBoxRepository extends AbstractEntityRepository {

	// The name of the json parameter ballot.
	private static final String JSON_NAME_PARAM_BALLOT = "ballot";

	// The name of the json parameter ballot alias.
	private static final String JSON_NAME_PARAM_BALLOT_ALIAS = "ballotAlias";

	private static final String EMPTY_BALLOT_BOX_FOUND = "Found an empty ballot box object. [ballotBoxId: %s]";

	BallotRepository ballotRepository;

	public BallotBoxRepository(
			final DatabaseManager databaseManager,
			@Lazy final BallotRepository ballotRepository) {
		super(databaseManager);
		this.ballotRepository = ballotRepository;
	}

	@PostConstruct
	@Override
	public void initialize() {
		super.initialize();
	}

	/**
	 * Returns the ballot id of the ballot box identified by the given ballotBoxId.
	 *
	 * @param ballotBoxId identifies the ballot box where to search. Must be non-null and a valid UUID.
	 * @return the ballot identifier.
	 * @throws FailedValidationException if the given ballot box is null or not a valid UUID.
	 * @throws IllegalArgumentException  if the found ballot box is a {@link JsonConstants#EMPTY_OBJECT}.
	 * @throws DatabaseException         if no ballot box is found.
	 */
	public String getBallotId(final String ballotBoxId) {
		validateUUID(ballotBoxId);

		final String ballotBoxAsJson = find(ballotBoxId);
		checkArgument(!ballotBoxAsJson.equals(JsonConstants.EMPTY_OBJECT), EMPTY_BALLOT_BOX_FOUND, ballotBoxId);

		final JsonObject ballotBox = JsonUtils.getJsonObject(ballotBoxAsJson);
		return ballotBox.getJsonObject(JSON_NAME_PARAM_BALLOT).getString(JsonConstants.ID);
	}

	/**
	 * Returns the date from which the ballot box identified by the given ballotBoxId is valid.
	 *
	 * @param ballotBoxId identifies the ballot box where to search. Must be non-null and a valid UUID.
	 * @return the ballot box start date.
	 * @throws FailedValidationException if the given ballot box is null or not a valid UUID.
	 * @throws IllegalArgumentException  if the found ballot box is a {@link JsonConstants#EMPTY_OBJECT}.
	 * @throws DatabaseException         if no ballot box is found.
	 */
	public LocalDateTime getDateFrom(final String ballotBoxId) {
		validateUUID(ballotBoxId);

		final String ballotBoxAsJson = find(ballotBoxId);
		checkArgument(!ballotBoxAsJson.equals(JsonConstants.EMPTY_OBJECT), EMPTY_BALLOT_BOX_FOUND, ballotBoxId);

		final JsonObject ballotBox = JsonUtils.getJsonObject(ballotBoxAsJson);
		return LocalDateTime.parse(ballotBox.getString(JsonConstants.DATE_FROM), DateTimeFormatter.ISO_DATE_TIME);
	}

	/**
	 * Returns the date until which the ballot box identified by the given ballotBoxId is valid.
	 *
	 * @param ballotBoxId identifies the ballot box where to search. Must be non-null and a valid UUID.
	 * @return the ballot box finish date.
	 * @throws FailedValidationException if the given ballot box is null or not a valid UUID.
	 * @throws IllegalArgumentException  if the found ballot box is a {@link JsonConstants#EMPTY_OBJECT}.
	 * @throws DatabaseException         if no ballot box is found.
	 */
	public LocalDateTime getDateTo(final String ballotBoxId) {
		validateUUID(ballotBoxId);

		final String ballotBoxAsJson = find(ballotBoxId);
		checkArgument(!ballotBoxAsJson.equals(JsonConstants.EMPTY_OBJECT), EMPTY_BALLOT_BOX_FOUND, ballotBoxId);

		final JsonObject ballotBox = JsonUtils.getJsonObject(ballotBoxAsJson);
		return LocalDateTime.parse(ballotBox.getString(JsonConstants.DATE_TO), DateTimeFormatter.ISO_DATE_TIME);
	}

	/**
	 * Returns the grace period of the ballot box identified by the given ballotBoxId.
	 *
	 * @param ballotBoxId identifies the ballot box where to search. Must be non-null and a valid UUID.
	 * @return the grace period.
	 * @throws FailedValidationException if the given ballot box is null or not a valid UUID.
	 * @throws IllegalArgumentException  if the found ballot box is a {@link JsonConstants#EMPTY_OBJECT}.
	 * @throws DatabaseException         if no ballot box is found.
	 */
	public int getGracePeriod(final String ballotBoxId) {
		validateUUID(ballotBoxId);

		final String ballotBoxAsJson = find(ballotBoxId);
		checkArgument(!ballotBoxAsJson.equals(JsonConstants.EMPTY_OBJECT), EMPTY_BALLOT_BOX_FOUND, ballotBoxId);

		final JsonObject ballotBox = JsonUtils.getJsonObject(ballotBoxAsJson);
		return ballotBox.getInt(JsonConstants.GRACE_PERIOD);
	}

	/**
	 * Indicates if the ballot box corresponding to the given ballot box id is a test ballot box.
	 *
	 * @param ballotBoxId the ballot box id. Must be non-null and a valid UUID.
	 * @return true if the corresponding ballot box is a test ballot box, false otherwise.
	 * @throws FailedValidationException if the given ballot box is null or not a valid UUID.
	 * @throws IllegalArgumentException  if the found ballot box is a {@link JsonConstants#EMPTY_OBJECT}.
	 * @throws DatabaseException         if no ballot box is found.
	 */
	public boolean isTestBallotBox(final String ballotBoxId) {
		validateUUID(ballotBoxId);

		final String ballotBoxAsJson = find(ballotBoxId);
		checkArgument(!ballotBoxAsJson.equals(JsonConstants.EMPTY_OBJECT), EMPTY_BALLOT_BOX_FOUND, ballotBoxId);

		final JsonObject ballotBox = JsonUtils.getJsonObject(ballotBoxAsJson);
		return ballotBox.getBoolean(JsonConstants.TEST);
	}

	/**
	 * Lists the aliases of the ballot boxes which belongs to the specified ballot.
	 *
	 * @param ballotId the ballot identifier.
	 * @return the aliases.
	 * @throws DatabaseException failed to list aliases.
	 */
	public List<String> listAliases(final String ballotId) {
		validateUUID(ballotId);

		final String sql = "select alias from " + entityName() + " where ballot.id = :ballotId";
		final Map<String, Object> parameters = singletonMap("ballotId", ballotId);
		final List<ODocument> documents;
		try {
			documents = selectDocuments(sql, parameters, -1);
		} catch (final OException e) {
			throw new DatabaseException("Failed to list aliases.", e);
		}
		final List<String> aliases = new ArrayList<>(documents.size());
		for (final ODocument document : documents) {
			aliases.add(document.field("alias", String.class));
		}
		return aliases;
	}

	/**
	 * Lists the id of the ballot boxes which belongs to the specified ballot.
	 *
	 * @param ballotId the ballot identifier.
	 * @return the ballot box ids.
	 * @throws DatabaseException failed to list identifiers.
	 */
	public List<String> listBallotBoxIds(final String ballotId) {
		validateUUID(ballotId);

		final String sql = "select id from " + entityName() + " where ballot.id = :ballotId";
		final Map<String, Object> parameters = singletonMap("ballotId", ballotId);
		final List<ODocument> documents;
		try {
			documents = selectDocuments(sql, parameters, -1);
		} catch (final OException e) {
			throw new DatabaseException("Failed to list ids.", e);
		}
		final List<String> ids = new ArrayList<>(documents.size());
		for (final ODocument document : documents) {
			ids.add(document.field("id", String.class));
		}
		return ids;
	}

	/**
	 * Updates the content of a ballotBox with the alias of its related ballot.
	 *
	 * @param ballotBoxIds - the list of ballotboxes to update.
	 */
	public void updateRelatedBallotAlias(final List<String> ballotBoxIds) {
		checkNotNull(ballotBoxIds).forEach(Validations::validateUUID);
		final List<String> ballotBoxIdsCopy = List.copyOf(ballotBoxIds);
		try {
			for (final String ballotBoxId : ballotBoxIdsCopy) {
				final ODocument ballotBox = getDocument(ballotBoxId);
				final String ballotId = ballotBox.field("ballot.id", String.class);
				final List<String> aliases = ballotRepository.listAliases(ballotId);
				// should be only one alias. to maintain compatibility with FE,
				// save
				// as comma-separated string
				ballotBox.field(JSON_NAME_PARAM_BALLOT_ALIAS, String.join(",", aliases));
				saveDocument(ballotBox);
			}
		} catch (final OException e) {
			throw new DatabaseException("Failed to update related ballot aliases.", e);
		}
	}

	/**
	 * Returns the ballot boxes corresponding to a specific electoral board ID.
	 *
	 * @param electoralBoardId the electoral board identifier.
	 * @return the ballot boxes in JSON format.
	 */
	public String findByElectoralBoard(final String electoralBoardId) {
		validateUUID(electoralBoardId);

		final Map<String, Object> attributes = singletonMap(JsonConstants.ELECTORAL_BOARD_DOT_ID, electoralBoardId);
		return list(attributes);
	}

	/**
	 * Lists the ballot boxes corresponding to a specific election event ID.
	 *
	 * @param electionEventId the election event identifier.
	 * @return the ballot boxes in JSON format.
	 * @throws DatabaseException failed to list the ballot boxes.
	 */
	public String listByElectionEvent(final String electionEventId) {
		validateUUID(electionEventId);

		return list(singletonMap("electionEvent.id", electionEventId));
	}

	@Override
	protected String entityName() {
		return BallotBox.class.getSimpleName();
	}
}
