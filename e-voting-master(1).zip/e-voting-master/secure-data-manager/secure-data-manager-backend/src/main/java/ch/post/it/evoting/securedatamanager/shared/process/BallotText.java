/*
 * (c) Copyright 2024 Swiss Post Ltd.
 */
package ch.post.it.evoting.securedatamanager.shared.process;

/**
 * The class representing a ballot text.
 */
@SuppressWarnings("java:S2094")
public class BallotText {

}
