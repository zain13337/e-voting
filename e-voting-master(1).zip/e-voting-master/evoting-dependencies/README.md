# Evoting Dependencies

This directory contains the POM.xml file that centralizes the dependency management and allows us to create and maintain well-defined third-party components and library versions.
